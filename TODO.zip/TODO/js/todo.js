function UpdateToInputList(){
	var list = document.createElement("li");
	var inputStore= document.getElementById("todo_names").value;
	var text = document.createTextNode(inputStore);
	list.appendChild(text);

	//condition of accepting the input
	if(inputStore === " "){
		alert("input cannot be empty");
	}
	else{
		document.getElementById("todo_list").appendChild(list);
	}
	document.getElementById("todo_names").value = " ";


var createCloseSpan = document.createElement("span");
var txt = document.createTextNode("\u00D7");
createCloseSpan.className = "close";
createCloseSpan.appendChild(txt);
list.appendChild(createCloseSpan);

var close = document.getElementsByClassName("close");
 for(var i=0;i<close.length;i++){
 	close[i].onclick = function(){
 		var div = this.parentElement;
 		div.style.display ="none";
 	}
 }
 
}

//creating the remove button to each li item
var myList = document.getElementsByTagName("li");
for( var i=0; i < myList.length;i++){
var createCloseSpan = document.createElement("span");
var txt = document.createTextNode("\u00D7");
createCloseSpan.className = "close";
createCloseSpan.appendChild(txt);
myList[i].appendChild(createCloseSpan);
}

//clicking on close button 
 var close = document.getElementsByClassName("close");
 for(var i=0;i<close.length;i++){
 	close[i].onclick = function(){
 		var div = this.parentElement;
 		div.style.display ="none";
 	}
 }