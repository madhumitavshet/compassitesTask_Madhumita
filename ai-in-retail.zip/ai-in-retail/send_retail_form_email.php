<?php

$to = "sandhya.jaiswal@compassitesinc.com,marco@bootupventures.com";
$subject = "Enquiry From AI in Retail;

$name = $_POST['name'];
$email=$_POST['email'];
$contactnumber = $_POST['contactnumber'];
$companyname = $_POST['companyname'];

$msg = "Name : ". $name . "<p>" . "Email : ". $email . "<p>" . "Contact Number : " . $contactnumber . "<p>" . "Company name : ". $companyname;

//$msg = "test";
// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// send email
$ok = mail($to,$subject,$msg,$headers);
if($ok) {
            echo "Form submitted successfully";
            echo "<script>setTimeout(\"location.href = 'https://bootupventures.com/ai-in-retail';\",3000);</script>";
         }else{
            die("Sorry but the email could not be sent. Please go back and try again!");
         }
?>
