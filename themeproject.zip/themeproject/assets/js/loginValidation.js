// function login_function () {
// 	var username = document.getElementById("username").value;
//     var password = document.getElementById("pwd").value;

//     document.getElementById("login").addEventListener("click",  function(){
//     	alert("santhosh")
//     });
// }



function validate(){
var username = document.getElementById("username").value;
var password = document.getElementById("pwd").value;
if(username == "mad" && password == "madhu"){
	alert("Login Sucessfully!");

}

else if((username == null ||username == "") && (password == null || password == "")){
	alert("field left blank!!");
}
else{
	alert("Login failed - Please enter correct Username and Password");
}
}






// var lgbtn = document.getElementById("login");

// lgbtn.addEventListener("click", validate)


